import setuptools

exec(open('setup.py').read())
