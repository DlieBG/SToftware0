.. _combinatorics-group_constructs:

Group constructors
==================

.. module:: sympy.combinatorics.group_constructs

.. autofunction:: DirectProduct
