Utilities
---------

.. automodule:: sympy.physics.optics.utils
   :members:
