==============================================
Kane's Method & Lagrange's Method (Docstrings)
==============================================

KaneMethod
==========

.. automodule:: sympy.physics.mechanics.kane
   :members:


LagrangesMethod
===============

.. automodule:: sympy.physics.mechanics.lagrange
   :members:
