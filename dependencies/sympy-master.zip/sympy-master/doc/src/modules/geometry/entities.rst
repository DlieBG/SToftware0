Entities
--------

.. module:: sympy.geometry.entity

.. autoclass:: sympy.geometry.entity.GeometryEntity
   :members:
