Points
------

.. module:: sympy.geometry.point

.. autoclass:: Point
   :members:

.. autoclass:: Point2D
   :members:

.. autoclass:: Point3D
   :members:
